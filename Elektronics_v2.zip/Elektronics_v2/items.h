#ifndef ITEMS_H
#define ITEMS_H
#include <iostream>
#include <string>
#include <vector>
using std::string;
using std::vector;

class Component {
private:
    string nome;
public:
    Component(string n = "indefinito");
    virtual ~Component() = default;
    string getNome() const;
};

class Ram : public Component{
private:
    int gb;
    string type;
public:
    Ram(string n = "indefinito", int giga = 0, string t = "indefinito");
    virtual bool operator==(const Ram& c) const;
    virtual bool operator<=(const Ram& c) const;
    virtual bool operator>=(const Ram& c) const;
    int getGb() const;
    string getType() const;
};

class CPU: public Component{
private:
    double clock;
    string graphic;
public:
    CPU(string n = "indefinito", double cl = 0, string gp = "non presente");
    virtual bool operator==(const CPU& c) const;
    virtual bool operator<=(const CPU& c) const;
    virtual bool operator>=(const CPU& c) const;
    double getClock() const;
    string getGraphic() const;
};

class Cooling: public Component
{
private:
    string type;
public:
    Cooling(string n = "indefinito", string type = "aria");
    virtual bool operator==(const Cooling& c) const;
    string getType() const;

};

class GPU : public Component
{
private:
    int memory;
    double clock;
public:
    GPU(string n = "indefinito", int mem = 0, double cl = 0);
    virtual bool operator==(const GPU& c) const;
    virtual bool operator<=(const GPU& c) const;
    virtual bool operator>=(const GPU& c) const;
    int getMemory() const;
    double getClock() const;
};

class HardDisk : public Component{
private:
    int gb;
    string type;
public:
    HardDisk(string n = "indefinito", int giga = 0, string type = "Metal Disk");
    virtual bool operator==(const HardDisk& c) const;
    virtual bool operator<=(const HardDisk& c) const;
    virtual bool operator>=(const HardDisk& c) const;
    int getGb() const;
    string getType() const;
};

class Resolution: public Component
{
private:
    int resolution[2];
public:
    Resolution();
    virtual bool operator==(const Component* c) const;
    virtual bool operator<=(const Component* c) const;
    virtual bool operator>=(const Component* c) const;
    void getResolution() const;
};

class Battery: public Component
{
private:
    int mAh;
    double battery_hour;
public:
    Battery(string n = "indefinito", int mAh = 0, double bh = 0);
    virtual bool operator==(const Battery& c) const;
    virtual bool operator<=(const Battery& c) const;
    virtual bool operator>=(const Battery& c) const;
    int getMAh() const;
    double getBattery_hour() const;
};

class Fotocamera: public Component
{
private:
    int num_fotocamere;
    vector<int> megapixel;
    bool sensore_infrarossi;
    bool flash;
public:
    Fotocamera(int num, vector<int> megap, bool infrarossi = false, bool f = false);
    virtual bool operator==(const Fotocamera& c) const;
    virtual bool operator<=(const Fotocamera& c) const;
    virtual bool operator>=(const Fotocamera& c) const;
    int getNum_fotocamere() const;
    vector<int> getMegapixel() const;
    bool getSensore() const;
    bool getFlash() const;
};

class Tastiera : public Component
{
private:
    string type;
    bool retroilluminata;
    string colori;
public:
    Tastiera(string t = "meccanica", bool retro = false, string colori = "bianco");
    bool operator==(Fotocamera& c) const;
    bool operator<=(Fotocamera& c) const;
    bool operator>=(Fotocamera& c) const;
};

class Schermo : public Component
{
private:
    Resolution res;
    double size;
public:
    Schermo(Resolution r, double s);
    virtual ~Schermo() = default;
    virtual int energy() = 0;
    virtual void setResolution(int[2]);
    virtual void setSize(double);
};

class Computer
{
private:
    string nome;
    Ram* ram;
    CPU* processore;
    GPU* graphic;
    HardDisk* HDD;
    Cooling* raffreddamento;
    double prezzo;
    string colore;
public:
    Computer(string nom = "Computer", Ram* r = new Ram(), CPU* c = new CPU(), GPU* g =new GPU(), HardDisk* hdd = new HardDisk(), Cooling* raf = new Cooling() ,double prez = 0, string col = "n/d");
    virtual ~Computer();
    const Ram& getRam() const;
    const CPU& getCPU() const;
    const GPU& getGPU() const;
    const HardDisk& getHDD() const;
    const Cooling& getraff() const;
    double getPrezzo() const;
    string getColore() const;
    string getNome() const;
    bool operator ==(const Computer&) const;
    bool operator >=(Computer&) const;
    bool operator <=(Computer&) const;
};

class Tablet : virtual public Computer
{
private:
    Battery bat;
    bool touch;
    int multitouch;
    bool penna;
public:
    Tablet(int r,string rt,string c,double cc, string cg, string cool,int h,string ht,int sh, string sht,string g,int gm,string sg,int sgm, double me[3],int prez,string col,int re[2], double s, int bat, int bath, bool t, int multit, bool pen);
    virtual void setBattery();
    virtual void setBatteryHour();
    virtual void setTouch();
    virtual void setMultiTouch();

};

class PC : virtual public Computer
{
private:

    int battery;
    int battery_hour;
    double weight;
    string tastiera;
    bool retroilluminazione;
    string webcam;
    int megapixel;
public:
    PC(int r,string rt,string c,double cc, string cg, string cool,int h,string ht,int sh, string sht,string g,int gm,string sg,int sgm, double me[3],int prez,string col, int re[2], double s, int bat, int bath, double w, string tas, bool retro, string wcam, bool mp);
};

class TwoInOne : public Tablet, public PC
{
private:
    bool tastiera;
public:
    TwoInOne(int r,string rt,string c,double cc, string cg, string cool,int h,string ht,int sh, string sht,string g,int gm,string sg,int sgm, double me[3],int prez,string col,int re[2], double s, int bat, int bath, bool t, int multit, bool pen, double w, string tas, bool retro, string wcam, bool mp);
    string getInfo() const;
};

class Telefono
{
private:
    int battery;
    int battery_hour;
    bool wifi;
    int sim;
    bool GPS;
    int mp_f;
    int mp_p;
    bool flash;
    bool touch;
    bool g3;
public:
    Telefono(int re[2], double s, int bat, int bath, bool wifi, int sim, bool gps, int mp_f, int mp_p, bool f, bool t, bool g3);
    virtual string getInfo() const;
};

class SmartPhone : public Telefono, public Computer
{
private:
    string marca;
    bool g4;
    string tipo_sim;
    bool sensore_di_prox;
    int mp_2p;
    int mp_3p;
    int mp_4p;
    int mp_2f;
    string display;
    bool multitouch;
    bool schermo_curvo;
    int peso;
    string scocca;
    string sistema_operativo;
public:
    SmartPhone(int re[2], double s, int bat, int bath, bool wifi, int sim, bool gps, int mp_f, int mp_p, bool f, bool t, bool g3, int r,string rt,string c,double cc, string cg, string cool,int h,string ht,int sh, string sht,string g,int gm,string sg,int sgm, double me[3], int prez, string col,string m, bool g4, string ts, bool prox_sens, int mp_2p, int mp_3p, int mp_4p, int mp_2f, string disp, bool mt, bool curvo, int peso ,string scod, string os);
    string getInfo() const;
};


#endif // ITEMS_H
