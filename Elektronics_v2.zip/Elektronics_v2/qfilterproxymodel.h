#ifndef QFILTERPROXYMODEL_H
#define QFILTERPROXYMODEL_H

#include <QSortFilterProxyModel>
class articolo;
/*
 * Classe proxy che funzionerà da intermediario fra QListModelAdapter e ListView
 */
class QFilterProxyModel : public QSortFilterProxyModel {
public:
    QFilterProxyModel(QObject* = nullptr);

    //bool toggleType(const QModelIndex&);
    bool insertRows(int, int = 1, const QModelIndex& = QModelIndex()) override;
    bool removeRows(int, int = 1, const QModelIndex& = QModelIndex()) override;
    articolo* getElement(const QModelIndex&);
protected:
    bool filterAcceptsRow(int, const QModelIndex&) const override;
};

#endif // QFILTERPROXYMODEL_H
