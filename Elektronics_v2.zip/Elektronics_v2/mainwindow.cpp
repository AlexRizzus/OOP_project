#include "mainwindow.h"
#include "qlistmodeladapter.h"
#include "listview.h"
#include "qfilterproxymodel.h"
#include "addlayout.h"
#include "itemwindow.h"

#include <QDesktopWidget>
#include <QApplication>

#include <QLayout>
#include <QPushButton>
#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QMessageBox>
#include <QLineEdit>

MainWindow::MainWindow(QWidget *parent) : QWidget(parent),
    searchbar(new QLineEdit(this)),
    view(new ListView(this))
{

    // centra la finestra nello schermo
    setFixedSize(QSize(1200, 800));
    move(QApplication::desktop()->screen()->rect().center() - rect().center());
    setWindowTitle(tr("Todo App")); // titolo applicazione
    setWindowIcon(QIcon(":/images/icon")); // icona del programma

    // Widget a dimensione fissa non ridimensionabile


    // avvia caricamento del modello
    //loadData();

    // fornisce alla view il modello dei dati che deve riflettere
    AddLayout* insert = new AddLayout();
    proxymodel = new QFilterProxyModel(this);
    model = new QListModelAdapter(this, insert);
    proxymodel->setSourceModel(model);
    view->setModel(proxymodel);

    searchbar->setPlaceholderText("Ricerca");
    //crea i widget

    // PULSANTI
    QPushButton* addButton = new QPushButton("Aggiungi", this);
    QPushButton* removeButton = new QPushButton("Rimuovi", this);

    // MENÙ e MENUBAR
    QMenuBar* menuBar = new QMenuBar();
    QMenu* menu = new QMenu("File", menuBar);
    QAction* saveAction = new QAction("Salva", menu);
    QAction* exitAction = new QAction("Esci", menu);
    // Setup del menù
    menuBar->addMenu(menu);
    menu->addAction(saveAction);
    menu->addAction(exitAction);

    // LAYOUT
    QVBoxLayout* mainLayout = new QVBoxLayout(this);

    // Searchbar sottolayout
    QHBoxLayout* searchLayout = new QHBoxLayout();
    searchLayout->addWidget(searchbar);

    // Pulsanti sottolayout
    QHBoxLayout* buttonsLayout = new QHBoxLayout();
    buttonsLayout->addWidget(addButton);
    buttonsLayout->addWidget(removeButton);

    // Setup Main layout
    mainLayout->addWidget(menuBar);
    mainLayout->addLayout(searchLayout);
    mainLayout->addWidget(view, 0, Qt::AlignCenter);
    mainLayout->addWidget(insert);
    mainLayout->addLayout(buttonsLayout); // stretch = 50 per distanziare i bottoni

    // CONNECT
    connect(saveAction, SIGNAL(triggered()), this, SLOT(saveData()));
    connect(exitAction, SIGNAL(triggered()), this, SLOT(close()));
    connect(addButton, SIGNAL(clicked()), this, SLOT(addComputer()));
    connect(removeButton, SIGNAL(clicked()), this, SLOT(removeComputer()));
    connect(searchbar, SIGNAL(textChanged(QString)), this, SLOT(textFilterChanged()));
    connect(view, SIGNAL(doubleClicked(const QModelIndex&)), this, SLOT(computerSelected(const QModelIndex&)));
}

// NB: non distrugge i QWidget (di quello se ne occupa Qt)
MainWindow::~MainWindow() {}

/*
 * Ritorna la dimensione ottimale della finestra
 */
QSize MainWindow::sizeHint() const {
    return QSize(1080, 700);
}

/* Aggiunge un nuovo  al modello e lo seleziona nella view */
void MainWindow::addComputer() {
    proxymodel->insertRows(proxymodel->rowCount(), 1);

    view->clearSelection();
    view->selectionModel()->clearCurrentIndex();
    view->selectionModel()->select(proxymodel->index(model->rowCount() - 1, 0), QItemSelectionModel::Select);
}


// Rimuove il Computer Selezionato

void MainWindow::removeComputer() {
    // prende l'elenco degli elementi selezionati dalla view
    const QModelIndexList selection = view->selectionModel()->selectedIndexes();
    if(selection.size() > 0)
        proxymodel->removeRows(selection.at(0).row(),1);
}

void MainWindow::computerSelected(const QModelIndex& i) {
    ItemWindow* details = new ItemWindow(this, new articolo(new Computer("SONO NUOVO")));
    details->show();

}
