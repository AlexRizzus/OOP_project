#ifndef ADDLAYOUT_H
#define ADDLAYOUT_H

#include <QWidget>
#include <QLineEdit>
#include <string>

class AddLayout : public QWidget
{
private:
    QLineEdit* nome_Computer;
public:
    AddLayout(QWidget* parent = nullptr);
    std::string getNome() const;
};

#endif // ADDLAYOUT_H
