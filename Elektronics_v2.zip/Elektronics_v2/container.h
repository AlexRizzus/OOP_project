#ifndef CONTAINER_H
#define CONTAINER_H
#include "items.h"


enum bollino { convenienza, prestazioni, rapporto};
enum categoria {computer, telefono, tablet, dueinuno, pc, smartPhone};
enum caratteristica {RAM, Cpu, HardDisk, Gpu, Tastiera};
class articolo
{
public:
    Computer* p;
    bool offerta;
    int numPezzi;
    bollino boll;
    bool news;
    string immagine;
    articolo(Computer* = nullptr);
    ~articolo();
    articolo(const articolo&);
    articolo& operator=(const articolo&);
    Computer& operator*() const;
    Computer* operator->() const;
};
template<class T>
class Container
{
    friend class iteratore;
private:
    T* vector;
    int size;
    int maxSize;
public:
    class iteratore {
        friend class Container<T>;
    private:
        T* punt;
    public:
        bool operator==(iteratore) const;
        bool operator!=(iteratore) const;
        bool operator=(iteratore) const;
        iteratore& operator++();
        iteratore& operator++(int);
        T& operator*() const;
    };
    Container(T* p = nullptr, int s = 0);
    ~Container();
    int getSize() const;
    int getMaxSize() const;
    void increaseSize();
    void removeEl(int);
    void insertEl(T&);
    T* getEl(int) const;
    iteratore& begin() const;
    iteratore& end() const;
    T& operator[](iteratore) const;
    T& operator*(iteratore&) const;
};

articolo* piuconveniente(const Container<articolo>&);
articolo* performanceMigliori(const Container<articolo>&);
Container<articolo>& ComputerByCPU(const CPU&, Container<articolo&>);
Container<articolo>& ComputerByRAM(const Ram&, Container<articolo&>);
Container<articolo>& ComputerByGPU(const GPU&, Container<articolo&>);
Container<articolo>& PhoneByPhotos(const Fotocamera&, Container<articolo&>);
Container<articolo>& NewEntries(const Container<articolo>&);
Container<articolo>& OfferteDelGiorno(const Container<articolo>&);

#endif // CONTAINER_H
