#include "itemwindow.h"
#include "container.h"
#include <QCheckBox>
#include <QLayout>
#include <QLabel>
ItemWindow::ItemWindow(QWidget* parent, articolo* item): QWidget(parent)
{
    QCheckBox* check = new QCheckBox(this);
    QLabel* nome = new QLabel(this);
    QString qt = QString::fromStdString((*item)->getNome());
    nome->setText(qt);
    QVBoxLayout* mainLayout = new QVBoxLayout(this);
    mainLayout->addWidget(check);
}
