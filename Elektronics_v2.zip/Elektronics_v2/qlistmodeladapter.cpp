#include "qlistmodeladapter.h"
#include "container.h"
#include "addlayout.h"
#include <QFont>

QListModelAdapter::QListModelAdapter(QObject* parent, const AddLayout* ins) :
    QAbstractListModel(parent),
    model(new Container<articolo>()), insert(ins) {}

QListModelAdapter::~QListModelAdapter() {
    delete model;
    delete insert;
}

/*
 * Ritorna la dimensione (numero di righe) del modello
 */
int QListModelAdapter::rowCount(const QModelIndex&) const {
    return model->getSize();
}
/*
int QListModelAdapter::columnCount(const QModelIndex&) const
{
    return 5;
}
*/
QVariant QListModelAdapter::data(const QModelIndex& index, int role) const {
    if (!index.isValid() || index.row() >= model->getSize())
        return QVariant();

    if (role == Qt::DisplayRole || role == Qt::EditRole) {
        Container<articolo>::iteratore it = model->begin();
        for(int i = 0; i < index.row(); i++)
        {
            ++it;
        }
        return QString::fromStdString((*it)->getNome());
    }

    if (role == Qt::FontRole) {

        }

    return QVariant();
}

bool QListModelAdapter::removeRows(int begin, int count, const QModelIndex& parent) {
    beginRemoveRows(parent, begin, begin + count - 1);
    model->removeEl(begin);
    endRemoveRows();
    return true;
}

bool QListModelAdapter::insertRows(int begin, int count, const QModelIndex& parent) {
    beginInsertRows(parent, begin, begin + count - 1);
    articolo art = articolo(new Computer(insert->getNome()));
    model->insertEl(art); // effettuare l'aggiunta sul modello dei dati
    endInsertRows();
    return true;
}

articolo* QListModelAdapter::getElement(const QModelIndex& index)
{
    //return model->getEl(index.row());
    return nullptr;
}
