#include "container.h"
articolo::articolo(Computer* t) : p(t), offerta(false),numPezzi(0),news(true),immagine("non definita")
{
}

articolo::~articolo()
{
    if(p)
    delete p;
}

articolo::articolo(const articolo& a)
{
    if(p)
    {
        delete p;
    }
    p = new Computer(*a);
    offerta = a.offerta;
    numPezzi = a.numPezzi;
    boll = a.boll;
    news = a.news;
    immagine = a.immagine;
}
articolo& articolo::operator=(const articolo& a)
{
    if(&a != this)
    {
        if(p)
    {
        delete p;
    }
    p = new Computer(*a);
    offerta = a.offerta;
    numPezzi = a.numPezzi;
    boll = a.boll;
    news = a.news;
    immagine = a.immagine;
    }
    return *this;
}
Computer& articolo::operator*() const
{
    return *p;
}

Computer* articolo::operator->() const
{
    return p;
}
template<class T>
Container<T>::Container(T* p, int s)
{
    if (s != 0)
    {
        T* a = new T[s*2];
        if (p)
        {
            for(int i = 0; i < s; i++)
            {
                a[i] = p[i];
            }
    }
    vector = a;
    size = s;
    maxSize = s*2;
    }
    else
    {
        T* a = new T[10];
        size = 0;
        maxSize = 10;
        vector = a;
    }

}
template<class T>
Container<T>::~Container()
{
    if(vector)
    delete vector;
}
template<class T>
int Container<T>::getSize() const
{
    return size;
}
template<class T>
int Container<T>::getMaxSize() const
{
    return maxSize;
}
template<class T>
bool Container<T>::iteratore::operator==(iteratore it) const
{
    return (punt->p == it.punt->p);
}
template<class T>
bool Container<T>::iteratore::operator!=(iteratore it) const
{
    return !(punt->p == it.punt->p);
}
template<class T>
typename Container<T>::iteratore& Container<T>::iteratore::operator++()
{
    punt = punt+1;
    return *this;
}
template<class T>
typename Container<T>::iteratore& Container<T>::iteratore::operator++(int i)
{
    iteratore aux = *this;
    punt = punt+1;
    return aux;
}
template<class T>
T& Container<T>::iteratore::operator*() const
{
    return *punt;
}
template<class T>
void Container<T>::increaseSize()
{
    T* temp = new T[maxSize*2];
    for (int i = 0; i < maxSize; i++)
    {
        temp[i] = vector[i];
    }
    maxSize = maxSize * 2;
}
template<class T>
void Container<T>::insertEl(T& p)
{
    if (maxSize == size)
    {
        increaseSize();
    }
    iteratore it = end();
    *(it) = p;
    size++;
}
template<class T>
void Container<T>::removeEl(int j)
{
    if (j <= size)
    {
        iteratore it = begin();
        for(int i = 0; i <= (j-1); i++)
        {
            it++;
        }
        delete it.punt;
        iteratore aux = it;
        it++;
        for(int i = j; i < size-2; i++)
        {
            aux = it;
            aux++;
            it++;
        }
        size--;
    }
}
template<class T>
T* Container<T>::getEl(int j) const
{
    iteratore it = begin();
    for(int i = 0; i < j; i++)
    {
        ++it;
    }
    T* aux = new T((*it));
    return aux;
}

articolo* piuconveniente(const Container<articolo>& con)
{
    Container<articolo>::iteratore it = con.begin();
    double min = con[it]->getPrezzo();
    articolo* artmin = &con[it];
    it++;
    for(int i = 1; i<con.getSize();i++)
    {
        if ((con[it])->getPrezzo() < min)
        {
            min = (con[it])->getPrezzo();
            artmin = &con[it];
        }
        it++;
    }
    return artmin;
}

articolo* performanceMigliori(const Container<articolo>& con)
{
    Container<articolo>::iteratore it = con.begin();
    CPU MaxPerformance = (*it)->getCPU();
    articolo* max = &con[it];
    for(int i = 0; i < con.getSize(); i++)
    {
        if (MaxPerformance.getClock() < (*it)->getCPU().getClock())
        {
            max = &con[it];
            MaxPerformance = (*it)->getCPU();
        }
    }
    return max;
}

Container<articolo>& ComputerByCPU(const CPU& c, Container<articolo>& con)
{
    Container<articolo> result = Container<articolo>();
    Container<articolo>::iteratore it = con.begin();
    for(it; it != con.end(); it++)
    {
        if(!((*it)->getCPU() == c))
        {
            result.insertEl(*it);
        }
    }
    return result;
}

Container<articolo>& ComputerByRAM(const Ram& r, Container<articolo>& con)
{
    Container<articolo> result = Container<articolo>();
    Container<articolo>::iteratore it = con.begin();
    for(it; it != con.end(); it++)
    {
        if(!((*it)->getRam() == r))
        {
            result.insertEl(*it);
        }
    }
    return result;
}

Container<articolo>& ComputerByGPU(const GPU& g, Container<articolo>& con)
{
    Container<articolo> result = Container<articolo>();
    Container<articolo>::iteratore it = con.begin();
    for(it; it != con.end(); it++)
    {
        if(!((*it)->getGPU() == g))
        {
           result.insertEl(*it);
        }
    }
    return result;
}

Container<articolo>& NewEntries(const Container<articolo>& con)
{
    Container<articolo> result = Container<articolo>();
    Container<articolo>::iteratore it = con.begin();
    for(it; it != con.end(); ++it)
    {
        if ((*it).news)
        {
            result.insertEl(*it);
        }
    }
    return result;
}

Container<articolo>& OfferteDelGiorno(const Container<articolo>& con)
{
    Container<articolo> result = Container<articolo>();
    Container<articolo>::iteratore it = con.begin();
    for(it; it != con.end(); it++)
    {
        if((*it).offerta)
        {
           result.insertEl(*it);
        }
    }
    return result;
}
template<class T>
typename Container<T>::iteratore& Container<T>::begin() const
{
    iteratore aux;
    aux.punt = vector;
    return aux;
}
template<class T>
typename Container<T>::iteratore& Container<T>::end() const
{
    iteratore aux;
    aux.punt = &vector[size];
    return aux;
}
template<class T>
T& Container<T>::operator[](iteratore it) const
{
    return *(it.punt);
}
template<class T>
T& Container<T>::operator*(iteratore& it) const
{
    return *(it.punt);
}

