#include "items.h"

/*
 *
 *        COMPONENTI BASE
 *
 *
 */

//CLASSE BASE COMPONENT
Component::Component(string n) : nome(n) {}


string Component::getNome() const {return nome;}

//RANDOM ACCESS MEMORY
Ram::Ram(string n, int giga, string t) : Component(n), gb(giga), type(t) {}

bool Ram::operator==(const Ram& c) const
{
    return (getNome() == c.getNome() && gb == c.getGb() && type == c.getType());
}

bool Ram::operator<=(const Ram& c) const
{
    return gb <= c.getGb();
}

bool Ram::operator>=(const Ram& c) const
{
    return gb <= c.getGb();
}

int Ram::getGb() const {return gb;}

string Ram::getType() const {return type;}

//PROCESSORE
CPU::CPU(string n, double cl, string gp): Component(n), clock(cl), graphic(gp) {}

bool CPU::operator==(const CPU&c) const
{
    return ( getNome()==c.getNome() && clock == c.getClock() && graphic == c.getGraphic());
}

bool CPU::operator<=(const CPU&c) const
{
    return (clock <= c.getClock());
}
bool CPU::operator>=(const CPU&c) const
{
    return (clock >= c.getClock());
}

double CPU::getClock() const {return clock;}

string CPU::getGraphic() const {return graphic;}

//SISTEMA DI RAFFREDDAMENTO
Cooling::Cooling(string n, string t) : Component(n), type(t) {}

bool Cooling::operator==(const Cooling& c) const
{
    return (getNome() == c.getNome() && type == c.getType());
}

string Cooling::getType() const {return type;}

//SCHEDA GRAFICA
GPU::GPU(string n, int mem, double cl): Component(n), memory(mem), clock(cl) {}

bool GPU::operator==(const GPU& c) const
{
    return (getNome() == c.getNome() && clock == c.getClock() && memory == c.getMemory());
}

bool GPU::operator<=(const GPU& c) const
{
    return memory <= c.getMemory();
}
bool GPU::operator>=(const GPU& c) const
{
    return memory >= c.getMemory();
}

int GPU::getMemory() const {return memory;}

double GPU::getClock() const {return clock;}

//HARD DISK
HardDisk::HardDisk(string n, int giga, string t) : Component(n), gb(giga), type(t) {}

bool HardDisk::operator==(const HardDisk& c) const
{
    return (getNome() == c.getNome() && gb == c.getGb() && type == c.getType());
}
bool HardDisk::operator<=(const HardDisk& c) const
{
    return (gb <= c.getGb());
}
bool HardDisk::operator>=(const HardDisk& c) const
{
    return (gb >= c.getGb());
}

int HardDisk::getGb() const {return gb;}

string HardDisk::getType() const {return type;}

//RESOLUTION
/*

Resolution::Resolution()

 Rifare resolution*/

Battery::Battery(string n, int mAh, double bh): Component(n), mAh(mAh), battery_hour(bh) {}

bool Battery::operator==(const Battery& c) const
{
    return (getNome() == c.getNome() && battery_hour == c.getBattery_hour() && mAh == c.getMAh());
}
bool Battery::operator<=(const Battery& c) const
{
    return mAh <= c.getMAh();
}
bool Battery::operator>=(const Battery& c) const
{
    return mAh >= c.getMAh();
}

int Battery::getMAh() const {return mAh;}

double Battery::getBattery_hour() const {return battery_hour;}

Fotocamera::Fotocamera(int num, vector<int> megap, bool infrarossi, bool f) : Component(), num_fotocamere(num), megapixel(megap), sensore_infrarossi(infrarossi), flash(f) {}

bool Fotocamera::operator==(const Fotocamera& c) const
{
    return (getNome() == c.getNome() && num_fotocamere == c.getNum_fotocamere() && megapixel == c.getMegapixel() && sensore_infrarossi == c.getSensore() && flash == c.getFlash());
}
bool Fotocamera::operator<=(const Fotocamera& c) const
{
    return num_fotocamere <= c.getNum_fotocamere();
}
bool Fotocamera::operator>=(const Fotocamera& c) const
{
    return num_fotocamere == c.getNum_fotocamere();
}

int Fotocamera::getNum_fotocamere() const {return num_fotocamere;}

vector<int> Fotocamera::getMegapixel() const {return megapixel;}

bool Fotocamera::getSensore() const {return sensore_infrarossi;}

bool Fotocamera::getFlash() const {return flash;}
/*
 *
 *
 *
 *          GERARCHIA DELLE CLASSI PRODOTTI ELETTRONICI
 *
 *
 *
 */
//COMPUTER
Computer::Computer(string nom,Ram* r, CPU* c, GPU* g, HardDisk* hdd, Cooling* raf,double prez, string col) : nome(nom),ram(r), processore(c), graphic(g), HDD(hdd),raffreddamento(raf), prezzo(prez),colore(col)
{

}

Computer::~Computer()
{
    delete ram;
    delete processore;
    delete graphic;
    delete HDD;
    delete raffreddamento;
}

bool Computer::operator==(const Computer& c) const
{
    return (*ram == c.getRam() && *processore == c.getCPU() && *graphic == c.getGPU() && *HDD == c.getHDD() && *raffreddamento == c.getraff());
}

const Ram& Computer::getRam() const { return *ram;}

const CPU& Computer::getCPU() const {return *processore;}

const GPU& Computer::getGPU() const {return *graphic;}

const HardDisk& Computer::getHDD() const {return *HDD;}

const Cooling& Computer::getraff() const {return *raffreddamento;}

double Computer::getPrezzo() const {return prezzo;}

string Computer::getColore() const {return colore;}

string Computer::getNome() const {return nome;}

