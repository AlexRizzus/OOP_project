#include "addlayout.h"

#include <QHBoxLayout>
AddLayout::AddLayout(QWidget* parent) : QWidget(parent), nome_Computer(new QLineEdit())
{
    QHBoxLayout* mainLayout = new QHBoxLayout(this);
    mainLayout->addWidget(nome_Computer);
}

std::string AddLayout::getNome() const
{
    return nome_Computer->text().toStdString();
}
