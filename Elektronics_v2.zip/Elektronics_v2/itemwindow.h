#ifndef ITEMWINDOW_H
#define ITEMWINDOW_H

#include <QWidget>
class articolo;
class ItemWindow : public QWidget
{
public:
    ItemWindow(QWidget* parent = nullptr, articolo* = nullptr);
};

#endif // ITEMWINDOW_H
